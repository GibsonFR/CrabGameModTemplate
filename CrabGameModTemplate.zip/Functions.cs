﻿namespace GibsonTemplateMod
{
    //Ici on stock les fonctions, dans des class pour la lisibilité du code dans Plugin.cs 

    //Cette class regroupe un ensemble de fonction plus ou moins utile
    public class Utility
    {
        //Cette fonction envoie un message dans le chat de la part du client
        public static void SendMessage(string message)
        {
            Variables.chatBoxInstance.SendMessage(message);
        }

        //Cette fonction envoie un message dans le chat de la part du client en mode Force (seul le client peut voir le message)
        public static void ForceMessage(string message)
        {
            Variables.chatBoxInstance.ForceMessage(message);
        }

        //Cette fonction envoie un message dans le chat de la part du server, marche uniquement en tant que Host de la partie
        public static void SendServerMessage(string message)
        {
            ServerSend.SendChatMessage(1, message);
        }

        //Cette Fonction permet d'écrire une ligne dans un fichier txt
        public static void Log(string path, string line)
        {
            // Utiliser StreamWriter pour ouvrir le fichier et écrire à la fin
            using (StreamWriter writer = new StreamWriter(path, true))
            {
                writer.WriteLine(line); // Écrire la nouvelle ligne
            }
        }

        //Cette fonction vérifie si une fonction crash sans interrompre le fonctionnement d'une class/fonction, et retourne un booleen
        public static bool DoesFunctionCrash(Action function, string functionName, string logPath)
        {
            try
            {
                function.Invoke();
                return false;
            }
            catch (Exception ex)
            {
                Log(logPath, $"[{GetCurrentTime()}] Erreur [{functionName}]: {ex.Message}");
                return true;
            }
        }
        //Cette fonction créer un dossier si il n'existe pas déjà
        public static void CreateFolder(string path, string logPath)
        {
            try
            {
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
            }
            catch (Exception ex)
            {
                Log(logPath, "Erreur [CreateFolder] : " + ex.Message);
            }
        }
        //Cette fonction créer un fichier si il n'existe pas déjà
        public static void CreateFile(string path, string logPath)
        {
            try
            {
                if (!File.Exists(path))
                {
                    using (StreamWriter sw = File.CreateText(path))
                    {
                        sw.WriteLine("");
                    }
                }
            }
            catch (Exception ex)
            {
                Log(logPath, "Erreur [CreateFile] : " + ex.Message);
            }
        }

        //Cette fonction réinitialise un fichier
        public static void ResetFile(string path, string logPath)
        {
            try
            {
                // Vérifier si le fichier existe
                if (File.Exists(path))
                {
                    using (StreamWriter sw = new StreamWriter(path, false))
                    {
                    }
                }
            }
            catch (Exception ex)
            {
                Log(logPath, "Erreur [ResetFile] : " + ex.Message);
            }
        }

        //Cette fonction  retourne une ligne spécifique prise dans un fichier  
        public static string GetSpecificLine(string filePath, int lineNumber , string logPath)
        {
            try
            {
                // Lire toutes les lignes du fichier
                string[] lines = File.ReadAllLines(filePath);

                // Vérifier si le numéro de ligne est valide
                if (lineNumber > 0 && lineNumber <= lines.Length)
                {
                    // Retourner la ligne spécifique
                    return lines[lineNumber - 1]; // Soustraire 1 car les indices commencent à 0
                }
                else
                {
                    Log(logPath, "ligne invalide.");
                }
            }
            catch (Exception ex)
            {
                Log(logPath, "Erreur [GetSpecificLine] : " + ex.Message);
            }

            return null;
        }
        //Cette fonction retourne l'heure actuelle
        public static string GetCurrentTime()
        {
            return DateTime.Now.ToString("HH:mm:ss");
        }


    }

    //Cette class regroupe un ensemble de fonction relative aux données de la partie
    public class GameData
    {
        //Cette fonction retourne le GameState de la partie en cours
        public static string GetGameState()
        {
            return UnityEngine.Object.FindObjectOfType<GameManager>().gameMode.modeState.ToString();
        }

        //Cette fonction retourne le LobbyManager
        public static LobbyManager GetLobbyManager()
        {
            return LobbyManager.Instance;
        }

        public static SteamManager GetSteamManager()
        {
            return SteamManager.Instance;
        }

        //Cette fonction retourne l'id de la map en cours
        public static int GetMapId()
        {
            return GetLobbyManager().map.id;
        }

        //Cette fonction retourne l'id du mode en cours
        public static int GetModeId()
        {
            return GetLobbyManager().gameMode.id;
        }

        //Cette fonction retourne le nom de la map en cours
        public static string GetMapName()
        {
            return GetLobbyManager().map.mapName;
        }

        //Cette fonction retourne le nom du mode en cours
        public static string GetModeName()
        {
            return UnityEngine.Object.FindObjectOfType<LobbyManager>().gameMode.modeName;
        }

        //Cette fonction retourne le GameManager
        public static GameManager GetGameManager()
        {
            try
            {
                return GameObject.Find("/GameManager (1)").GetComponent<GameManager>();
            }
            catch
            {
                return GameObject.Find("/GameManager").GetComponent<GameManager>();
            }
        }
    }

    public class PlayersData
    {
        //Cette fonction vérifie si un joueur se trouve au niveau du sol (par défault sur un sol plat, ground = 2f)
        public static bool IsGrounded(Vector3 playerPos, float ground, GameObject player)
        {
            RaycastHit hit;
            Vector3 startPosition = playerPos;
            float distanceToGround;

            // Créez un LayerMask qui ignore le layer 'Player'
            int layerMask = 1 << LayerMask.NameToLayer("Player");
            layerMask = ~layerMask; // Inverse le mask pour ignorer le layer 'Player'

            if (Physics.Raycast(startPosition, Vector3.down, out hit, Mathf.Infinity, layerMask))
            {
                distanceToGround = hit.distance;

                if (hit.distance >= ground)
                    return false;
                else
                    return true;
            }
            return false;
        }
    }

    public class ClientData
    {
        //Cette fonction retourne le steam Id du client sous forme de ulong
        public static ulong GetClientId()
        {
            return GetClientManager().steamProfile.m_SteamID;
        }

        //Cette fonction retourne un booleen qui détermine si le client est Host ou non
        public static bool IsClientHost()
        {
            return SteamManager.Instance.IsLobbyOwner() && !LobbyManager.Instance.Method_Public_Boolean_0();
        }

        //Cette fonction retourne le GameObject du client
        public static GameObject GetClientObject()
        {
            return GameObject.Find("/Player");
        }
        //Cette fonction retourne le Rigidbody du client
        public static Rigidbody GetClientBody()
        {
            return GetClientObject() == null ? null : GetClientObject().GetComponent<Rigidbody>();
        }
        //Cette fonction retourne le PlayerManager du client
        public static PlayerManager GetClientManager()
        {
            return GetClientObject() == null ? null : GetClientObject().GetComponent<PlayerManager>();
        }

        //Cette fonction retourne la class Movement qui gère les mouvements du client
        public static PlayerMovement GetClientMovement()
        {
            return GetClientObject() == null ? null : GetClientObject().GetComponent<PlayerMovement>();
        }

        //Cette fonction retourne l'inventaire du client
        public static PlayerInventory GetClientInventory()
        {
            return GetClientObject() == null ? null : PlayerInventory.Instance;
        }

        //Cette fonction retourne le status du client
        public static PlayerStatus GetClientStatus()
        {
            return GetClientObject() == null ? null : PlayerStatus.Instance;
        }

        //Cette fonction retourne la Camera du client
        public static Camera GetClientCamera()
        {
            return GetClientBody() == null ? null : UnityEngine.Object.FindObjectOfType<Camera>();
        }

        //Cette fonction retourne l'username du client
        public static string GetClientUsername()
        {
            return GetClientManager() == null ? null : GetClientManager().username.ToString();
        }
        
        //Cette fonction retourne la rotation du client
        public static Quaternion? GetClientRotation()
        {
            return GetClientObject() == null ? null : GetClientCamera().transform.rotation;
        }

        //Cette fonction retourne la position du client
        public static Vector3? GetClientPosition()
        {
            return GetClientObject() == null ? null : GetClientBody().transform.position;
        }
        //Cette fonction retourne la vitesse du client
        public static Vector3? GetClientSpeed()
        {
            return GetClientObject() == null ? null : Variables.clientBody.velocity;
        }
        //Cette fonction retourne si le client a un item ou non équipé
        public static bool ClientHasItemCheck()
        {
            return PlayerInventory.Instance.currentItem == null ? false : true;
        }

        //Cette fonction désactive les mouvements du client
        public static void DisableClientMovement()
        {
            if (Variables.clientBody != null && Variables.clientBody.position != Vector3.zero)
            {
                Variables.clientBody.isKinematic = true;
                Variables.clientBody.useGravity = false;
            }
        }

        //Cette fonction active les mouvements du client
        public static void EnableClientMovement()
        {
            if (Variables.clientBody != null && Variables.clientBody.position != Vector3.zero)
            {
                Variables.clientBody.isKinematic = false;
                Variables.clientBody.useGravity = true;
            }
        }
    }

}
